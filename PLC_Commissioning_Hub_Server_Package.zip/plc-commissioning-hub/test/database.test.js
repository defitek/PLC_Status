import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { openDatabase } from '../database.js';

test('database seeds controllers and supports CRUD for every module', () => {
  const directory = mkdtempSync(join(tmpdir(), 'plc-hub-'));
  const repository = openDatabase(join(directory, 'test.db'));

  try {
    assert.deepEqual(repository.controllers().map(item => item.code), ['HB522', 'UB512']);
    assert.ok(repository.statusItems('HB522').length >= 1);

    const status = repository.createStatus({ controller: 'HB522', station: 'ST522.99', function_detail: 'API test', status: 'Not started' });
    assert.equal(status.controller, 'HB522');
    assert.equal(repository.updateStatus(status.id, { status: 'Done' }).status, 'Done');
    repository.deleteStatus(status.id);

    const task = repository.createTask({ controller: 'UB512', title: 'Test task' });
    assert.equal(repository.updateTask(task.id, { status: 'In progress' }).status, 'In progress');
    repository.deleteTask(task.id);

    const point = repository.createOpenPoint({ controller: 'HB522', title: 'Test open point' });
    assert.equal(repository.updateOpenPoint(point.id, { status: 'Closed' }).status, 'Closed');
    repository.deleteOpenPoint(point.id);

    const note = repository.createDailyNote({ controller: 'UB512', author: 'Tester', content: 'Test note' });
    assert.equal(repository.updateDailyNote(note.id, { type: 'Decision' }).type, 'Decision');
    repository.deleteDailyNote(note.id);

    const dashboard = repository.dashboard('all');
    assert.ok(dashboard.total >= 10);
    assert.ok(dashboard.progress >= 0 && dashboard.progress <= 100);
  } finally {
    repository.close();
    rmSync(directory, { recursive: true, force: true });
  }
});
